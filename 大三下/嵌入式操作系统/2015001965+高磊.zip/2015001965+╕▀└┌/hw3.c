#include <stdio.h>
#include <stdlib.h>
int main()
{
    system("grep abc /home/sn.txt > /tmp/b.txt");
    return 0;
}