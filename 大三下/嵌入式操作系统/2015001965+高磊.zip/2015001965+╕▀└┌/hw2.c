#include <string.h>
#include <sys/errno.h>
#include <sys/signal.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#define SIZE 10
#define WRITEDATA SIGUSR2
#define READ_DATA SIGUSR1
int Shared_arr[SIZE] = {};
int Cnt_given_at_29087876 = 0;
int RDWRCount = 0, Shared_arrIndex = 0, out_given_at_29087876 = 0;
int ProducerConsumerPipe[2] = {};
int CurPid = 0;
short CompleteFirstHandler = 0;
void consumer()
{
        kill( getpid(), WRITEDATA);     // Inform consumer(self) to write data;
        while ( 2 != CompleteFirstHandler);
}
void producer()
{
        while ( -1 != CompleteFirstHandler);
}
void HandleData( int CurSig)
{
        if ( WRITEDATA == CurSig)
        {
                if ( 0 == CurPid)
                {
                        printf( "Child  Received signal WRITEDATA\n");
                        printf( "Child  writing eleven times\n");
                        // fflush(stdout);
                        RDWRCount=10;
                        int WriteRet = write(ProducerConsumerPipe[1], &RDWRCount, sizeof(RDWRCount));
                        if ( -1 == WriteRet)
                        {
                                printf( "write1 error from child : %s\n", strerror(errno));
                                _exit(1);
                        }
                        WriteRet = write(ProducerConsumerPipe[1], Shared_arr, sizeof(Shared_arr));
                        if ( -1 == WriteRet)
                        {
                                printf( "write2 error from child : %s\n", strerror(errno));
                                _exit(1);
                        }
                        while ( ( RDWRCount <= SIZE) && ( 0 <= RDWRCount) )
                        {
                                WriteRet = 0;
                                Shared_arr[Shared_arrIndex] = rand() % 100; // produce an item, add to buffer
                                printf( "RDWRCount [%02d] Child  writing  \t%d\t%d\n", RDWRCount, Shared_arr[Shared_arrIndex], Shared_arrIndex);
                                Shared_arrIndex = (Shared_arrIndex + 1) % SIZE;
                                // Handle in based on your requirement.
                                WriteRet = write(ProducerConsumerPipe[1], Shared_arr, sizeof(Shared_arr));
                                if ( -1 == WriteRet)
                                {
                                        printf( "write4 error from child : %s\n", strerror(errno));
                                        _exit(1);
                                }
                                RDWRCount--;
                        }
                        // After writing Inform producer to read data;
                        kill( getppid(), READ_DATA);    // Inform producer to read data;
                }
                else
                {
                        printf( "Parent Received signal WRITEDATA\n");
                        printf( "Parent writing eleven times\n");
                        // fflush(stdout);
                        RDWRCount=10;
                        int WriteRet = write(ProducerConsumerPipe[1], &RDWRCount, sizeof(RDWRCount));
                        if ( -1 == WriteRet)
                        {
                                printf( "write5 error from parent: %s\n", strerror(errno));
                                exit(1);
                        }
                        WriteRet = write(ProducerConsumerPipe[1], Shared_arr, sizeof(Shared_arr));
                        if ( -1 == WriteRet)
                        {
                                printf( "write6 error from parent: %s\n", strerror(errno));
                                exit(1);
                        }
                        while ( ( RDWRCount <= SIZE) && ( 0 <= RDWRCount) )
                        {
                                WriteRet = 0;
                                Shared_arr[Shared_arrIndex] = rand() % 100; // produce an item, add to buffer
                                printf( "RDWRCount [%02d] Parent writing  \t%d\t%d\n", RDWRCount, Shared_arr[Shared_arrIndex], Shared_arrIndex);
                                Shared_arrIndex = (Shared_arrIndex + 1) % SIZE;
                                // Handle in based on your requirement.
                                WriteRet = write(ProducerConsumerPipe[1], Shared_arr, sizeof(Shared_arr));
                                if ( -1 == WriteRet)
                                {
                                        printf( "write8 error from parent: %s\n", strerror(errno));
                                        exit(1);
                                }
                                RDWRCount--;
                        }
                        if ( 0 == CompleteFirstHandler)
                        {
                                if ( 0 == CurPid)
                                {
                                        kill( CurPid, READ_DATA);       // Inform consumer to read data;
                                        kill( getpid(), WRITEDATA);     // Inform producer to write data;
                                }
                        }
                }
                Shared_arrIndex = 0; // Reset Shared_arrIndex once completing write
                CompleteFirstHandler = CompleteFirstHandler +1;
        }
        else if ( READ_DATA == CurSig)
        {
                if ( 0 == CurPid)
                {
                        // sleep(30);
                        printf( "Child  Received signal READ_DATA\n");
                        int ReadRet = read( ProducerConsumerPipe[0], &RDWRCount, sizeof(RDWRCount));
                        if ( -1 == ReadRet)
                        {
                                printf( "read1 error from child : %s\n", strerror(errno));
                                _exit(1);
                        }
                        ReadRet = read(ProducerConsumerPipe[0], Shared_arr, sizeof(Shared_arr));
                        if ( -1 == ReadRet)
                        {
                                printf( "read2 error from child : %s\n", strerror(errno));
                                _exit(1);
                        }
                        while ( ( RDWRCount <= SIZE) && ( 0 <= RDWRCount) )
                        {
                                ReadRet = read(ProducerConsumerPipe[0], Shared_arr, sizeof(Shared_arr));
                                if ( -1 == ReadRet)
                                {
                                        printf( "read4 error from child: %s\n", strerror(errno));
                                        _exit(1);
                                }
                                else
                                {
                                        printf( "RDWRCount [%02d] Child reading\t%d\t%d\n", RDWRCount, Shared_arr[Shared_arrIndex], out_given_at_29087876);
                                        out_given_at_29087876 = (out_given_at_29087876 + 1) % SIZE;
                                        RDWRCount--;
                                }
                        }
                        // After completing read by child informing parent to send SIGQUIT signal.
                        kill( getppid(), SIGQUIT);
                        // Making parent to set th value of CompleteFirstHandler to -1
                }
                else
                {
                        printf( "Parent Received signal READ_DATA\n");
                        int ReadRet = read(ProducerConsumerPipe[0], &RDWRCount, sizeof(RDWRCount));
                        if ( -1 == ReadRet)
                        {
                                printf( "read5 error from parent: %s\n", strerror(errno));
                                _exit(1);
                        }
                        ReadRet = read(ProducerConsumerPipe[0], Shared_arr, sizeof(Shared_arr));
                        if ( -1 == ReadRet)
                        {
                                printf( "read6 error from parent: %s\n", strerror(errno));
                        }
                        else
                        {
                                while ( ( RDWRCount <= SIZE) && ( 0 <= RDWRCount) )
                                {
                                        Shared_arr[Shared_arrIndex] = rand() % 100; // produce an item, add to buffer
                                        printf( "RDWRCount [%02d] Parent reading  \t%d\t%d\n", RDWRCount, Shared_arr[Shared_arrIndex], Shared_arrIndex);
                                        Shared_arrIndex = (Shared_arrIndex + 1) % SIZE;
                                        ReadRet = read(ProducerConsumerPipe[0], Shared_arr, sizeof(Shared_arr));
                                        if ( -1 == ReadRet)
                                        {
                                                printf( "read8 error from parent: %s\n", strerror(errno));
                                                _exit(1);
                                        }
                                        RDWRCount--;
                                }
                        }
                        // After reading Inform consumer to write data;
                        if ( 0 == CompleteFirstHandler)
                        {
                                kill( getpid(), WRITEDATA);     // Inform producer to write data;
                                kill( CurPid, READ_DATA);       // Inform consumer to read  data;
                        }
                }
                Shared_arrIndex = 0; // Reset Shared_arrIndex once completing read
                CompleteFirstHandler = CompleteFirstHandler+1;
        }
        else if ( ( SIGQUIT == CurSig) && ( 0 != CurPid) )
        {
                CompleteFirstHandler = -1;
        }
}
int main()
{
        pipe(ProducerConsumerPipe);
        signal( SIGCHLD, SIG_IGN);      // Remove defunct process.
        signal( READ_DATA, HandleData);
        signal( WRITEDATA, HandleData);
        signal( SIGQUIT, HandleData);
        CurPid = fork();
        if ( 0 == CurPid)
        {
                consumer();
                printf( "Child  finished\n");
        }
        else
        {
                producer();
                printf( "Parent finished\n");
        }
        exit(0);
}