#include <stdio.h>
#include <stdlib.h>
int main(int argc,char *argv[]){
    if(argc != 3){
        fprintf(stderr,"Usage:%s srcFileName destFileName\n",argv[0]);
        exit(1);
    }
    FILE *src,*dest;
    if((src = fopen(argv[1],"r"))==NULL){
        fprintf(stderr,"cannot open file %s",argv[1]);
        exit(1);
    }
    if((dest = fopen(argv[2],"w"))==NULL){
        fprintf(stderr,"cannot open file %s",argv[2]);
        exit(1);
    }
    int c=fgetc(src);
    while(c!=EOF){
        fputc(c,dest);
        c=fgetc(src);
    }
    fclose(src);
    fclose(dest);
    return 0;
}
