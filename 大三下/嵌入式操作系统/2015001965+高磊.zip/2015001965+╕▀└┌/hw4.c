#include <stdlib.h>
#include <stdio.h>
#include <errno.h>
#include <string.h>
#include <netdb.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <unistd.h>
#include <pthread.h>
#define portnumber 3333

void *thread(int  fd){
    int bytes;
    char buffer[1024];
    if((bytes==read(fd, buffer, 1024))==-1)
    {
        fprintf(stderr, "%s\n",strerror(errno));
        pthread_exit(NULL);
    }
    printf("received %s\n",buffer);
    close(fd);
    pthread_exit(NULL);
}

int main(int argc, char *argv[])
{
    int listen_fd,accept_fd;
    struct sockaddr_in client_addr;
    int n;
    int nbytes;
    
    if((listen_fd=socket(AF_INET,SOCK_STREAM,0))==-1) 
    {
        printf("Socket error:%s\n\a",strerror(errno));
        exit(1);
    }
    
    
    bzero(&client_addr,sizeof(struct sockaddr_in)); 
    client_addr.sin_family=AF_INET;                 
    client_addr.sin_addr.s_addr=htonl(INADDR_ANY);  
    
    n=1;

    client_addr.sin_port=htons(portnumber);
    if(bind(listen_fd,(struct sockaddr *)(&client_addr),sizeof(client_addr))==-1)
    {
        printf("Bind error:%s\n\a",strerror(errno));
        exit(1);
    }
    

    listen(listen_fd,5);
    
    while(1)
    {
        
        accept_fd=accept(listen_fd,NULL,NULL);
        printf("waiting....\n");
        if(accept_fd<0)
        {
            printf("Accept Error:%s\n",strerror(errno));
            continue;
        }
      
        pthread_t pth;
        int ret=pthread_create(&pth, NULL, (void *)thread, accept_fd);
    }
}
